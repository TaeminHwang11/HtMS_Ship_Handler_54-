clearvars; clc;
folder = pwd;
if isempty(folder),folder=pwd;end
scenarioIDs=1:30;
horizon=500;
plotEvery=3;
scenarioFile=fullfile(folder,'SEGERO_SCENARIOS_30.mat');
ballTreeFile=fullfile(folder,'SEGERO_BALLTREE_LIBRARY.mat');
agentFile=fullfile(folder,'SEGERO_GLOBAL_DDPG_VDR30_V4_ALL_TRAIN_STARTS.mat');
assert(isfile(scenarioFile),'SEGERO_SCENARIOS_30.mat is missing.');
assert(isfile(ballTreeFile),'SEGERO_BALLTREE_LIBRARY.mat is missing.');
assert(isfile(agentFile),'The pretrained DDPG checkpoint is missing.');
S=load(scenarioFile,'scenarios');
A=load(ballTreeFile,'B');
Q=load(agentFile,'trainedAgent');
assert(isfield(S,'scenarios') && isfield(A,'B') && isfield(Q,'trainedAgent'));
scenarios=S.scenarios;
B=A.B;
agent=Q.trainedAgent;
agent.UseExplorationPolicy=false;
expected=["HDG_sin","HDG_cos","COG_sin","COG_cos","STW","SOG", ...
    "ROT","Rudder","Leeway","Surge","Sway","dHDG","dCOG", ...
    "dSTW","dSOG","dROT","dRudder","EXT_X","EXT_Y","toALTER"];
assert(isequal(string(B.searchFields(:))',expected));
assert(size(B.ZW,2)==20 && numel(B.mu)==20 && numel(B.sigma)==20);
assert(numel(B.maneuverID)==size(B.ZW,1) && numel(B.order)==size(B.ZW,1));
assert(numel(B.futureROT)==size(B.ZW,1) && numel(B.counterFlag)==size(B.ZW,1));
assert(all(B.sigma>0) && numel(unique(B.maneuverID))>=20);
observationInfo=getObservationInfo(agent);
actionInfo=getActionInfo(agent);
assert(prod(double(observationInfo.Dimension))==7);
assert(prod(double(actionInfo.Dimension))==3);
labels={'Fixed PID','RL-PID','Retrieval-Based PID'};
colors=[0.22 0.48 0.77;0.89 0.42 0.20;0.17 0.61 0.43];
allResults=table();
for sid=scenarioIDs
    matches=find(arrayfun(@(x)double(x.ScenarioID)==sid,scenarios));
    assert(numel(matches)==1,'Scenario ID is missing or duplicated.');
    sc=scenarios(matches);
    requested=double(sc.Angle_deg);
    state=repmat(segeroInitial(sc),1,3);
    H=nan(horizon+1,3);
    ROT=nan(horizon+1,3);
    RUD=nan(horizon+1,3);
    CMD=nan(horizon+1,3);
    for m=1:3
        H(1,m)=0;
        ROT(1,m)=state(m).rot;
        RUD(1,m)=state(m).rud;
    end
    fig=figure('Name',sprintf('SEGERO S%02d',sid), ...
        'Color','w','Position',[60 50 1110 890]);
    layout=tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
    lines=gobjects(4,3);
    axesList=gobjects(4,1);
    axisLabels={'Relative heading (deg)','ROT (deg/min)', ...
        'Recommended Order (deg)','Realized Rudder (deg)'};
    for p=1:4
        axesList(p)=nexttile(layout);
        hold(axesList(p),'on');
        for m=1:3
            lines(p,m)=animatedline(axesList(p),'Color',colors(m,:), ...
                'LineWidth',1.45,'DisplayName',labels{m});
        end
        xlim(axesList(p),[0 horizon]);
        ylabel(axesList(p),axisLabels{p});
        grid(axesList(p),'on');
    end
    yline(axesList(1),requested,'k--','Target','HandleVisibility','off');
    ylim(axesList(3),[-37 37]);
    ylim(axesList(4),[-37 37]);
    legend(axesList(1),labels,'Location','best');
    xlabel(axesList(4),'Simulated time (s)');
    for m=1:3
        addpoints(lines(1,m),0,0);
        addpoints(lines(2,m),0,ROT(1,m));
        addpoints(lines(4,m),0,RUD(1,m));
    end
    title(layout,sprintf('Scenario %02d | Target %+0.1f deg | t = 0 / %d s', ...
        sid,requested,horizon));
    drawnow;
    for t=1:horizon
        for m=1:3
            s=state(m);
            errorHeading=segeroWrap(s.goal-s.h);
            if m==2
                leeway=segeroWrap(s.cog-mod(s.h,360));
                observation=[errorHeading/60;s.rot/60;s.rud/35; ...
                    s.I/120;leeway/45;s.stw/20;s.dROT/60];
                observation=max(-4,min(4,observation));
                action=getAction(agent,{observation});
                if iscell(action),action=action{1};end
                action=double(action(:))';
                assert(numel(action)==3 && all(isfinite(action)));
                gains=[10 0.025 40].*max(0,min(1,action));
            else
                gains=double(B.fixedGains(:))';
            end
            s.I=segeroClip(s.I*exp(-1/25)+errorHeading,-120,120);
            base=gains(1)*errorHeading+gains(2)*s.I-gains(3)*s.rot/60;
            if m==3
                raw=segeroFeatures(s,errorHeading);
                q=((raw-double(B.mu(:))')./double(B.sigma(:))').* ...
                    sqrt(double(B.weights(:))');
                [ids,ds]=segeroQuery(B.tree,double(B.ZW),q, ...
                    double(B.maneuverID(:)),20);
                weight=exp(-(ds.^2-min(ds.^2))/(2*B.softmaxTemperature^2));
                weight=weight/sum(weight);
                orders=double(B.order(ids));
                angleGap=sum(weight.*abs(double(B.toALTER(ids))-errorHeading));
                meanOrder=sum(weight.*orders);
                orderSpread=sqrt(sum(weight.*(orders-meanOrder).^2));
                cd=1/(1+(median(ds)/(2.5*B.distanceScale))^2);
                ca=1/(1+(angleGap/B.angleMatchScale)^2);
                cs=1/(1+(orderSpread/B.orderConsensusScale)^2);
                confidence=segeroClip(cd*ca*(0.6+0.4*cs),0,1);
                futureROT=sum(weight.*double(B.futureROT(ids)));
                brakingShare=sum(weight.*double(B.counterFlag(ids)));
                referenceROT=segeroClip((1-0.48*confidence)*60*errorHeading/18+ ...
                    0.48*confidence*futureROT,-100,100);
                brakeGate=0;
                if errorHeading*s.rot>0 && abs(s.rot)>=1
                    projection=abs(s.rot)*13/60;
                    brakeGate=segeroClip((projection-abs(errorHeading))/max(2,projection),0,1);
                end
                orderShare=0.25*confidence;
                command=(1-orderShare)*base+orderShare*meanOrder+ ...
                    18*(referenceROT-s.rot)/60- ...
                    sign(s.rot)*21*brakeGate*(0.30+0.70*brakingShare);
            else
                command=base;
            end
            command=segeroClip(command,-35,35);
            s=segeroStep(s,command,B.P);
            state(m)=s;
            H(t+1,m)=s.h-s.h0;
            ROT(t+1,m)=s.rot;
            RUD(t+1,m)=s.rud;
            CMD(t,m)=command;
            addpoints(lines(1,m),t,H(t+1,m));
            addpoints(lines(2,m),t,ROT(t+1,m));
            addpoints(lines(3,m),t,command);
            addpoints(lines(4,m),t,RUD(t+1,m));
        end
        if t==1 || mod(t,plotEvery)==0 || t==horizon
            title(layout,sprintf('Scenario %02d | Target %+0.1f deg | t = %d / %d s', ...
                sid,requested,t,horizon));
            drawnow limitrate;
        end
        assert(all(isfinite([H(t+1,:),ROT(t+1,:),RUD(t+1,:),CMD(t,:)])));
    end
    summary=segeroSummary(sid,requested,H,RUD,horizon,labels);
    disp(summary);
    if isempty(allResults)
        allResults=summary;
    else
        allResults=[allResults;summary];
    end
end
disp(allResults);

function s=segeroInitial(sc)
s=struct();
s.h0=double(sc.ObservedHDG_deg);
s.h=s.h0;
s.goal=s.h0+double(sc.Angle_deg);
s.rot=double(sc.InitialROT_degmin);
s.rud=double(sc.InitialRudder_deg);
s.stw=double(sc.InitialSTW_knots);
s.sog=double(sc.InitialSOG_knots);
s.cog=double(sc.ObservedCOG_deg);
s.driftE=double(sc.DriftEast_mps);
s.driftN=double(sc.DriftNorth_mps);
s.yaw=double(sc.YawIncrement_degmin);
s.dHDG=double(sc.dHDG);
s.dCOG=double(sc.dCOG);
s.dSTW=double(sc.dSTW);
s.dSOG=double(sc.dSOG);
s.dROT=double(sc.dROT);
s.dRudder=double(sc.dRudder);
s.I=0;
end

function s=segeroStep(s,command,P)
old=s;
rate=double(P.rudderRate);
s.rud=old.rud+segeroClip(command-old.rud,-rate,rate);
r=(old.rot/60+double(P.rudderEffect)*s.rud)/ ...
    (1+double(P.turnDamping)*abs(old.rot/60));
s.rot=60*r+s.yaw;
s.h=old.h+s.rot/60;
vE=s.stw*(1852/3600)*sind(s.h)+s.driftE;
vN=s.stw*(1852/3600)*cosd(s.h)+s.driftN;
s.cog=mod(atan2d(vE,vN),360);
s.sog=hypot(vE,vN)/(1852/3600);
s.dHDG=segeroWrap(s.h-old.h);
s.dCOG=segeroWrap(s.cog-old.cog);
s.dSTW=s.stw-old.stw;
s.dSOG=s.sog-old.sog;
s.dROT=s.rot-old.rot;
s.dRudder=s.rud-old.rud;
end

function raw=segeroFeatures(s,remaining)
leeway=segeroWrap(s.cog-s.h);
velE=s.sog*(1852/3600)*sind(s.cog);
velN=s.sog*(1852/3600)*cosd(s.cog);
externalE=velE-s.stw*(1852/3600)*sind(s.h);
externalN=velN-s.stw*(1852/3600)*cosd(s.h);
raw=[sind(s.h),cosd(s.h),sind(s.cog),cosd(s.cog), ...
    s.stw,s.sog,s.rot,s.rud,leeway,s.sog*cosd(leeway), ...
    s.sog*sind(leeway),s.dHDG,s.dCOG,s.dSTW,s.dSOG, ...
    s.dROT,s.dRudder,externalE,externalN,remaining];
end

function [bestIdx,bestDistances]=segeroQuery(root,Z,q,maneuverID,k)
bestIdx=zeros(0,1);
bestDistances=zeros(0,1);
bestM=zeros(0,1);
visit(root);
assert(numel(bestIdx)==k && numel(unique(bestM))==k);
    function visit(node)
        bound=max(0,norm(q-node.center)-node.radius);
        if numel(bestIdx)>=k && bound>bestDistances(end)+1e-12
            return;
        end
        if ~isempty(node.indices)
            candidates=double(node.indices(:));
            distances=sqrt(sum((Z(candidates,:)-q).^2,2));
            for h=1:numel(candidates)
                index=candidates(h);
                dist=distances(h);
                mid=maneuverID(index);
                pos=find(bestM==mid,1);
                if ~isempty(pos)
                    if dist<bestDistances(pos)-1e-12 || ...
                            (abs(dist-bestDistances(pos))<=1e-12 && index<bestIdx(pos))
                        bestIdx(pos)=index;
                        bestDistances(pos)=dist;
                    else
                        continue;
                    end
                elseif numel(bestIdx)<k || dist<=bestDistances(end)+1e-12
                    bestIdx(end+1,1)=index;
                    bestDistances(end+1,1)=dist;
                    bestM(end+1,1)=mid;
                else
                    continue;
                end
                [~,order]=sortrows([bestDistances,bestM,bestIdx],[1 2 3]);
                if numel(order)>k,order=order(1:k);end
                bestIdx=bestIdx(order);
                bestDistances=bestDistances(order);
                bestM=bestM(order);
            end
            return;
        end
        if norm(q-node.left.center)<=norm(q-node.right.center)
            visit(node.left);
            visit(node.right);
        else
            visit(node.right);
            visit(node.left);
        end
    end
end

function tableOut=segeroSummary(sid,angle,H,RUD,N,labels)
rmse=zeros(3,1);
overshoot=zeros(3,1);
acquisition=nan(3,1);
rudderTravel=zeros(3,1);
tol=max(0.5,0.1*abs(angle));
for m=1:3
    err=angle-H(:,m);
    rmse(m)=sqrt(mean(err.^2));
    overshoot(m)=max(0,max(sign(angle)*H(:,m))-abs(angle));
    rudderTravel(m)=sum(abs(diff(RUD(:,m))));
    first=find(conv(double(abs(err)<=tol),ones(11,1),'valid')>=11-1e-12,1);
    if ~isempty(first)
        confirmed=first+10;
        if sum(abs(diff(H(1:confirmed,m))))<180
            acquisition(m)=confirmed-1;
        end
    end
end
tableOut=table(repmat(sid,3,1),string(labels(:)), ...
    repmat(angle,3,1),rmse,overshoot,acquisition,rudderTravel, ...
    'VariableNames',{'ScenarioID','Controller','Angle_deg','RMSE_deg', ...
    'Overshoot_deg','Acquisition_sec','RudderTravel_deg'});
end

function x=segeroClip(x,a,b)
x=max(a,min(b,x));
end

function x=segeroWrap(x)
x=mod(x+180,360)-180;
end
